/*
==================
Number Processing
==================

[INSTRUCTION]
Terdapat function numberProcessing yang menerima sebuah parameter berupa array,
function akan mencari nilai min , max, dan rata -rata, serta mengelompokan angka ganjil dan genap , lalu menggabungkannya menjadi string

[EXAMPLE]
input: [1, 3, 5, 1, 2, 8, 10, 0, 3]
output: "Min: 0, Max: 10, Avg: 3, Odds: 1-3-5-1-3, Evens: 2-8-10-0"


[RULES]
- Wajib menggunakan Pseudocode
- Tidak boleh menggunakan Function bawaan Math apapun.
- Jika mean dalam bentuk desimal, bulatkan kebawah.

*/

function numberProcessing(numberArr) {
  //your code here
}

console.log(numberProcessing([1, 3, 5, 1, 2, 8, 10, 0, 3]));
// "Min: 0, Max: 10, Avg: 3, Odds: 1-3-5-1-3, Evens: 2-8-10-0"
